<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Response;
use App\Models\Admission;
use App\Models\useruser;
use Illuminate\View\View;
use Illuminate\Support\Facades\Log;
use Hash;
use Session;

class submit_di extends Controller
{
    public function login()
    {
        return view("login");
    }

    public function registration()
    {
        return view("registration");
    }

    public function registerUSer(Request $request){
            $request->validate([
                'name'=>'required',
                'email'=>'required|email|unique:users',
                'password'=>'required|min:5|max:12'
    
            ]);

        $user = new useruser();
        $user->name = $request->name;
        $user->email = $request->email;
        $user->password = Hash::make($request->password);
        $res = $user->save();
        if($res){
            return back()->with('success', 'You have registered successfully');
        }
        else{
            return back()->with('fail','Something went wrong');
        }
}


public function loginUser(Request $request){
        $request->validate([

            'email'=>'required|email',
            'password'=>'required|min:5|max:12'

        ]);

        $user = useruser::where('email','=',$request->email)->first();
        if($user){
            if(Hash::check($request->password, $user->password)){
                $request->session()->put('loginId',$user->id);
                return redirect('index');
            }
            else{
                return back()->with('fail','Password does not matches');
            }

        }
        else{
            return back()->with('fail','This email is not registered');
        }

    }
}
