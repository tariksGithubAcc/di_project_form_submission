<?php

namespace App\Http\Controllers;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Models\Admission;
use Illuminate\View\View;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;


class di_submit extends Controller
{


    public function index()
    {
        $admissions = Admission::all();

        $distinctclass = Admission::select('classApplied')->distinct('classApplied')->get();
        // dd($distinctclass);
        return view('index', compact('admissions','distinctclass'));
       
    }

    public function admission_info()
    {
        return view('admission_info');
    }

    public function personal_info()
    {
        return view('personal_info');
    }

    public function sibling_info()
    {
        return view('sibling_info');
    }

    public function address_detail()
    {
        return view('address_detail');
    }

    public function parents_info()
    {
        return view('parents_info');
    }

    public function academic_info()
    {
        return view('academic_info');
    }

    public function contact_info()
    {
        return view('contact_info');
    }

    public function medical_history()
    {
        return view('medical_history');
    }

    public function hostel_info()
    {
        return view('hostel_info');
    }

    public function concession_info()
    {
        return view('concession_info');
    }

    public function documents_info()
    {
        return view('documents_info');
    }

    public function transport_detail()
    {
        return view('transport_detail');
    }

    public function registerUser(Request $request){
   
       
            // Insert validated data into $data
            $data = [
                'admissionNo' => $request['admissionNo123'],
                'rollNo' => $request['rollNo1'],
                'classApplied' => $request['classApplied'], // Changed to match the model
                'admissionDate' => $request['admissionDate'], // Changed to match the model
                'orientationDate' => $request['orientationDate'],
                'studentName' => $request['studentName'],
                'section' => $request['section'],
                'gender' => $request['gender'],
                'house' => $request['house'],
                'studentType' => $request['studentType'],
                'nationality' => $request['nationality'],
                'streamWing' => $request['streamWing'],
                'optionalSubject' => $request['optionalSubject'],
              
                'branchPreference' => $request['branchPreference'],
                'securityCase' => $request['securityCase'],
            ];
            // dd($data);
 
            if($request->editid==''){
                Admission::create($data);
                // Redirect back or to a success page
            return redirect()->back()->with('success', 'Admission details saved successfully!');
            }
            else{
                Admission:: where('id', $request->editid)->update($data);
                // Redirect back or to a success page
            return redirect()->back()->with('success', ' updated successfully!');
            }
            
            
            }

            public function update($admd)
            {
                    $editid = Admission::where('id', $admd)->first();
                  
                    $admissions=Admission::all();

                    return view('index',compact('editid','admissions'));
            }


    public function destroy(Request $request,$id)
    {
    
        $admission = Admission::findOrFail($id);
        $admission->delete();

        return redirect()->back()->with('success', 'Admission details deleted successfully!');
    }

    public function get_admission_data(Request $request)
    {

        $admissionNo = $request->admissionNo;
        
        $userData = Admission::select([
            'studentName',
            'admissionDate',
            'classApplied',
            'section',
            'gender',
            'house',
            'studentType',
            'nationality',
            'streamWing',
            'optionalSubject',
            'orientationDate',
            'branchPreference'
        ])->where('admissionNo', $admissionNo)->first();
        
        if ($userData) {
            return response()->json([
                'stuedntName' => $userData->studentName,
                'admissionDate' => $userData->admissionDate,
                'classApplied' => $userData->classApplied,
                'section' => $userData->section,
                'gender' => $userData->gender,
                'house' => $userData->house,
                'studentType' => $userData->studentType,
                'nationality' => $userData->nationality,
                'streamWing' => $userData->streamWing,
                'optionalSubject' => $userData->optionalSubject,
                'orientationDate' => $userData->orientationDate,
                'branchPreference' => $userData->branchPreference,
            ]);
        } else {
            return response()->json(['error' => 'User data not found'], 404);
        }
    }

    public function get_student_name(Request $request)
    {

        // dd($request->all());
        $ClassApplied = $request->ClassApplied;
        
        $user_Data = Admission::select([
            'studentName',
            
        ])->where('ClassApplied', $ClassApplied)->first();
        
        if ($user_Data) {
            return response()->json([
                'StudentName' => $user_Data->StudentName,
                'ClassApplied' => $user_Data->ClassApplied,
                
            ]);
        } else {
            return response()->json(['error' => 'User data not found'], 404);
        }
    }

    public function showChart()
    {
        // Example data from the database
        $data = Admission::select('admissionNo', DB::raw('count(*) as total'))
                          ->groupBy('admissionNo')
                          ->pluck('total', 'admissionNo');

        // Pass data to the view
        return view('chart', compact('data'));
    }
    

}
