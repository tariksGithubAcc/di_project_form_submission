<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\di_submit;
use App\Http\Controllers\submit_di;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('login');
});

Route::get('/index',[di_submit::class,'index']);
Route::get('/admission_info',[di_submit::class,'admission_info']);
Route::get('/personal_info',[di_submit::class,'personal_info']);

Route::get('/sibling_info',[di_submit::class,'sibling_info']);

Route::get('/address_detail',[di_submit::class,'address_detail']);

Route::get('/parents_info',[di_submit::class,'parents_info']);

Route::get('/academic_info',[di_submit::class,'academic_info']);

Route::get('/contact_info',[di_submit::class,'contact_info']);

Route::get('/medical_history',[di_submit::class,'medical_history']);

Route::get('/hostel_info',[di_submit::class,'hostel_info']);

Route::get('/concession_info',[di_submit::class,'concession_info']);

Route::get('/documents_info',[di_submit::class,'documents_info']);

Route::get('/transport_detail',[di_submit::class,'transport_detail']);

Route::get('/get-admission-data',[di_submit::class,'get_admission_data'])->name('get_admission_data');

Route::get('/get-student-name',[di_submit::class,'get_student_name'])->name('get_student_name');

Route::get('/chart', [di_submit::class, 'showChart']);






Route::get('/registration',[submit_di::class,'registration']);

Route::any('/register-user', [di_submit::class, 'registerUser'])->name('register-user');
Route::any('/register.user', [submit_di::class, 'registerUSer'])->name('register.user');

Route::get('/edit-id/{admd}', [di_submit::class, 'update'])->name('update');
Route::any('/deleteid/{id}', [di_submit::class, 'destroy'])->name('destroy'); 

Route::get('/login',[submit_di::class,'login']);
Route::post('/login-user',[submit_di::class,'loginUser'])->name('login-user');