<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Hello, world!</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            /* width: 200% */
        }
        .error{
            color:red;
        }
        .container {
            width: 500%;
            margin: 20px auto;
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-bottom: 10px;
            border-bottom: 1px solid #ddd;
            /* margin: 200%; */
        }
        .header h2 {
            margin: 0;
        }
        .form-section {
            display: flex;
            margin-top: 20px;
            /* margin: 200%; */
        }
        .form-section .nav {
            width: 20%;
            background-color: #2a3f54;
            color: white;
            padding: 10px;
        }
        .form-section .nav ul {
            list-style-type: none;
            padding: 0;
        }
        .form-section .nav ul li {
            padding: 10px 0;
            border-bottom: 1px solid #3c4b5a;
        }
        .form-section .nav ul li a {
            color: white;
            text-decoration: none;
        }
        .form-section .nav ul li a:hover {
            text-decoration: underline;
        }
        .form-content {
            width: 80%;
            padding: 20px;
        }
        .form-group {
            display: flex;
            margin-bottom: 15px;
        }
        .form-group label {
            width: 25%;
            padding: 10px;
            background: #f5f5f5;
            border: 1px solid #ddd;
        }
        .form-group input,
        .form-group select {
            width: 75%;
            padding: 10px;
            border: 1px solid #ddd;
            border-left: none;
        }
        .form-group input[type="radio"] {
            width: auto;
            margin-right: 10px;
        }

        .submitted_admission{
            /* border: 1px solid #dee2e6;
            padding: 10px;
            text-align: left;
            background-color: #FFC0CB;
            color: #495057; */

            box-sizing: border-box;
            margin-bottom: 30px;
            display: block;

        }
    </style>


  </head>
  <body>


  <div class="container">
        <div class="header">
            <h2>Pinegrove School, Subathu</h2>
            <div>Admin Pinegrove School</div>
        </div>
        <div class="form-section">
            <div class="nav">
                <ul>
                    <li><a href="admission_info">Admission Info</a></li>
                    <li><a href="personal_info">Personal Info</a></li>
                    <li><a href="sibling_info">Sibling Info</a></li>
                    <li><a href="address_detail">Address Detail</a></li>
                    <li><a href="parents_info">Parent/Guardian</a></li>
                    <li><a href="academic_info">Academic Info</a></li>
                    <li><a href="contact_info">Emergency Contacts</a></li>
                    <li><a href="medical_history">Medical History</a></li>
                    <li><a href="hostel_info">Hostel Info</a></li>
                    <li><a href="concession_info">Concession Info</a></li>
                    <li><a href="documents_info">Documents Upload</a></li>
                    <li><a href="transport_detail">Transport Detail</a></li>
                </ul>

            </div>

            <div class="container">
        <h2>Admission Form</h2>

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif
            

            <form method="POST" action="{{ route('register-user') }}">
    @csrf
    <?php if(isset($editid)){?>  
      <input type="hidden"  name="editid" value="{{$editid->id}}"> 
      <?php }?>
    <div class="form-content">
                <div class="form-group">
                    <label for="admissionNo">Admission No.</label>
                    <select class="form-control" name="admission_num" id="admissionNo">
                        <option>--Select--</option>
                        @foreach ($admissions as $user)
            <option value="{{ $user->admissionNo }}">{{ $user->admissionNo }}</option>
        @endforeach
                    </select>
                    
                    <input type="text" id="admissionNo" name="admissionNo123" <?php if(isset($editid)){?> value="{{$editid->admissionNo }}" <?php }?> >
                   
                </div>



                <div class="form-group">
                        <span>Hide name</span>
                        <input type="radio" class="form-control" name="toggleField" id="hideName">
                        <span>Hide Roll NO.</span>
                        <input type="radio" class="form-control" name="toggleField" id="hideRollNo">
                    </div>

                <div class="form-group">
                    <label for="admissionDate">Date of Admission</label>
                    <input type="date" id="admissionDate" name="admissionDate" value="2024-06-26">
                    @if ($errors->has('admissionDate'))
                      <div class="error" >{{ $errors->first('admissionDate') }}</div>
                    @endif
                </div>

                <div class="form-group">
                    <label for="rollNo">B-ID/Roll No.</label>
                    <input type="text" id="rollNo" name="rollNo1" <?php if(isset($editid)){?> value="{{$editid->rollNo }}" <?php }?> >
                    @if ($errors->has('rollNo'))
                    <div class="error" >{{ $errors->first('rollNo') }}</div>
                    @endif
                </div>

               
                <div class="form-group" >
                    <label for="studentName">Student Name</label>
                    <input type="text" id="studentName" name="studentName" <?php if(isset($editid)){?> value="{{$editid->studentName }}" <?php }?>>
                    @if ($errors->has('studentName'))
                        <div class="error" >{{ $errors->first('studentName') }}</div>
                    @endif
                </div>



                <div class="row">

                    <div class="col-lg-6">
                        <label for="ClassApplied">Class</label>
                        <select class="form-control" name="class_applied" id="ClassApplied " >
                            <option>select</option>

                           @foreach($distinctclass as $tarik)
                            <option value="{{$tarik->classApplied}}">{{$tarik->classApplied}}</option>
                          
                           @endforeach
                        </select>
                    </div>

                    <div class="col-lg-6">
                        <label for="StudentName">Student Name</label>
                        <select class="form-control" name="student_name" id="StudentName" >
                            <option value="{{$tarik->ClassApplied}}">{{$tarik->ClassApplied}}</option>

                        </select>
                    </div>


                </div><br><br>


               
                <div class="form-group">
                    <label for="classApplied">Class Applied For</label>
                    <select id="classApplied" name="classApplied" value="{{ old('classApplied') }}">
                        <option>Select</option>
                        <option <?php if(isset($editid) && $editid->classApplied='first' ){ echo "selected";   }?> value="first">first</option>
                        <option  <?php if(isset($editid) && $editid->classApplied='second' ){ echo "selected";   }?> value="second">second</option>
                    </select>
                    @if ($errors->has('classApplied'))
                         <div class="error" >{{ $errors->first('classApplied') }}</div>
                     @endif
                </div>

                <div class="form-group">
                    <label for="section">Section</label>
                    <select class="form-control" name="section" id="section" value="{{ old('section') }}">
                        <option>Select</option>
                        <option <?php if(isset($editid) && $editid->section='Lotus' ){ echo "selected";   }?> value="Lotus">Lotus</option>
                        <option <?php if(isset($editid) && $editid->section='Rose' ){ echo "selected";   }?> value="Rose">Rose</option>
                        <option <?php if(isset($editid) && $editid->section='Tulip' ){ echo "selected";   }?> value="Tulip">Tulip</option>
                    </select>
                    @if ($errors->has('section'))
                    <div class="error" >{{ $errors->first('section') }}</div>
                    @endif
                </div>
 

                <div class="form-group">
                    <label for="gender">Gender</label>
                    <select class="form-control" name="gender" id="gender">
                        <option>Select</option>
                        <option <?php if(isset($editid) && $editid->gender='male' ){ echo "selected";   }?> value="male">male</option>
                        <option <?php if(isset($editid) && $editid->gender='female' ){ echo "selected";   }?> value="female">female</option>
                    </select>
                    @if ($errors->has('gender'))
                      <div class="error" >{{ $errors->first('gender') }}</div>
                     @endif
                </div>

                <div class="form-group">
                    <label for="house">House</label>
                    <select class="form-control" name="house" id="house" value="{{ old('house') }}">
                        <option>Select</option>
                        <option <?php if(isset($editid) && $editid->house='bunglow' ){ echo "selected";   }?> value="bunglow">bunglow</option>
                        <option <?php if(isset($editid) && $editid->house='apartment' ){ echo "selected";   }?> value="apartment">apartment</option>  
                   </select>
                    @if ($errors->has('house'))
                                            <div class="error" >{{ $errors->first('house') }}</div>
                    @endif
                </div>

                
                <div class="form-group">
                    <label for="studentType">Student Type</label>
                    <select class="form-control" name="studentType" id="studentType">
                    @if ($errors->has('studentType'))
                                        <div class="error" >{{ $errors->first('studentType') }}</div>
                                    @endif
                <option <?php if(isset($editid) && $editid->studentType='Intelligent' ){ echo "selected";   }?> value="Intelligent">Intelligent</option>
                <option <?php if(isset($editid) && $editid->studentType='Average' ){ echo "selected";   }?> value="Average">Average</option>
                    
                </select>
                </div>
                <div class="form-group">
                    <label for="nationality">Nationality</label>
                    <select class="form-control" name="nationality" id="nationality">
                    @if ($errors->has('nationality'))
                                        <div class="error" >{{ $errors->first('nationality') }}</div>
                                    @endif
                <option <?php if(isset($editid) && $editid->nationality='Indian' ){ echo "selected";   }?> value="Indian">Indian</option>
                <option <?php if(isset($editid) && $editid->nationality='Muslim' ){ echo "selected";   }?> value="Muslim">Muslim</option>
                    
                </select>
                </div>
                <div class="form-group">
                    <label for="stream">Stream/Wing</label>
                    <select class="form-control" name="streamWing" id="streamWing">
                    @if ($errors->has('streamWing'))
                                        <div class="error" >{{ $errors->first('streamWing') }}</div>
                                    @endif
                <option <?php if(isset($editid) && $editid->streamWing='first' ){ echo "selected";   }?> value="first">first</option>
                <option <?php if(isset($editid) && $editid->streamWing='second' ){ echo "selected";   }?> value="second">second</option>
                    
                </select>
                </div>
                <div class="form-group">
                    <label for="subject">Optional Subject</label>
                    <select class="form-control" name="optionalSubject" id="optionalSubject">
                    @if ($errors->has('optionalSubject'))
                                        <div class="error" >{{ $errors->first('optionalSubject') }}</div>
                                    @endif
                <option <?php if(isset($editid) && $editid->optionalSubject='Hindi' ){ echo "selected";   }?> value="Hindi">Hindi</option>
                <option <?php if(isset($editid) && $editid->optionalSubject='English' ){ echo "selected";   }?> value="English">English</option>
                <option <?php if(isset($editid) && $editid->optionalSubject='Chemistry' ){ echo "selected";   }?> value="Chemistry">Chemistry</option>
                <option <?php if(isset($editid) && $editid->optionalSubject='Mathematics' ){ echo "selected";   }?> value="Mathematics">Mathematics</option>
                    
                </select>
                </div>

                <div class="form-group">
                <label for="reference">Reference (if any)</label>
                <input type="text" class="form-control" name="refrence" id="reference" <?php if(isset($editid)){?> value="{{$editid->orientationDate }}" <?php }?>>
            </div>

                <div class="form-group">
                    <label for="orientationDate">Orientation Date</label>
                    <input type="date" id="orientationDate" name="orientationDate" <?php if(isset($editid)){?> value="{{$editid->orientationDate }}" <?php }?>>
                    @if ($errors->has('orientationDate'))
                       <div class="error" >{{ $errors->first('orientationDate') }}</div>
                    @endif
                </div>

                <div class="form-group">
                    <label for="branch">Branch Preference</label>
                        <select class="form-control" name="branchPreference" id="branchPreference">
                            <option <?php if(isset($editid)){?> value="{{$editid->branchPreference }}" <?php }?> value="Lotus">Lotus</option>
                            <option <?php if(isset($editid)){?> value="{{$editid->branchPreference }}" <?php }?> value="Tulip">Tulip</option>
                            <option <?php if(isset($editid)){?> value="{{$editid->branchPreference }}" <?php }?> value="Rose">Rose</option>
                            <option <?php if(isset($editid)){?> value="{{$editid->branchPreference }}" <?php }?> value="Cherry">Cherry</option>
                        </select>
                @if ($errors->has('branchPreference'))
                    <div class="error" >{{ $errors->first('branchPreference') }}</div>
                @endif
                </div>
                <div class="form-group">
                    <label for="securityCase">Security Case</label>
                    <span>Yes</span><input type="radio" id="securityCaseYes" name="securityCase" value="Yes" <?php if(isset($editid) && $editid->securityCase='Yes' ){ echo "checked";   }?> checked>
                    <span>No</span> <input type="radio" id="securityCaseNo" name="securityCase" value="No" <?php if(isset($editid) && $editid->securityCase='No' ){ echo "checked";   }?>> 
                    @if ($errors->has('securityCase'))
                         <div class="error"  >{{ $errors->first('securityCase') }}</div>
                     @endif
                </div>
            </div>

            <button type="submit" class="btn btn-primary">Submit</button>

            <div class="submitted_admission">
<h2>Submitted Admissions</h2>
        <table class="table table-striped" border='1'>
            <thead>
                <tr>
                    <th>Admission No</th>
                    <th>Roll No</th>
                    <th>Class Applied</th>
                    <th>Admission Date</th>
                    <th>Orientation Date</th>
                    <th>Student Name</th>
                    <th>Section</th>
                    <th>Gender</th>
                    <th>House</th>
                    <th>Student Type</th>
                    <th>Nationality</th>
                    <th>Stream Wing</th>
                    <th>Optional Subject</th>
                    <th>Reference</th>
                    <th>Branch Preference</th>
                    <th>Security Case</th>
                </tr>
            </thead>
            <tbody>
                @foreach($admissions as $admission)
                    <tr>
                        <td>{{ $admission->admissionNo }}</td>
                        <td>{{ $admission->rollNo }}</td>
                        <td>{{ $admission->classApplied }}</td>
                        <td>{{ $admission->admissionDate }}</td>
                        <td>{{ $admission->orientationDate }}</td>
                        <td>{{ $admission->studentName }}</td>
                        <td>{{ $admission->section }}</td>
                        <td>{{ $admission->gender }}</td>
                        <td>{{ $admission->house }}</td>
                        <td>{{ $admission->studentType }}</td>
                        <td>{{ $admission->nationality }}</td>
                        <td>{{ $admission->streamWing }}</td>
                        <td>{{ $admission->optionalSubject }}</td>
                        <td>{{ $admission->reference }}</td>
                        <td>{{ $admission->branchPreference }}</td>
                        <td>{{ $admission->securityCase }}</td>
                        <td>
                        <!-- <button class="btn btn-warning" onclick="editAdmission({{ $admission->id }})">Edit</button> -->
                         <a href="{{ route('update',$admission->id)}}"><button type="button" class="btn-success">Edit</button></a>
                         <a href="{{ route('destroy',$admission->id)}}"><button type="button" class="btn btn-danger">Delete</button></a>
                         </td>


                    </tr>
                    </tr>
                @endforeach
            </tbody>
        </table>
</div>


<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form id="editForm" method="POST">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Edit Admission</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                
            </form>
        </div>
    </div>
</div>


    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>



    <script>
        $(document).ready(function() {
            $('input[type=radio][name=toggleField]').change(function() {
                if (this.id == 'hideName') {
                    $('#studentName').hide();
                } else if (this.id == 'hideRollNo') {
                    $('#rollNo').hide();
                }
            });
        });
    </script>


 <script>
$(document).ready(function() {
    $(document).on('change', '#admissionNo', function () {
        var admissionNo = $('#admissionNo').val();
        
        console.log("admission number id is " + admissionNo)

        $.ajax({
            url: '{{ route('get_admission_data') }}',
            method: 'GET',
            data: {'admissionNo': admissionNo},
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            },
            success: function (response) {
                console.log("Success:", response);

                $('#studentName').val(response.studentName);
                $('#dateOfAdmission').val(response.admissionDate);
                $('#classAppliedFor').val(response.classApplied);
                $('#section').val(response.section);
                $('#gender').val(response.gender);
                $('#house').val(response.house);
                $('#studentType').val(response.studentType);
                $('#nationality').val(response.nationality);
                $('#streamWing').val(response.streamWing);
                $('#optionalSubject').val(response.optionalSubject);
                $('#orientationDate').val(response.orientationDate);
                $('#branchPreference').val(response.branchPreference);
            },
            error: function (xhr, status, error) {
                console.error("AJAX Error:", error);
            }
        });
    });
});


</script>
 <!-- fetch data in options box coreespondint to another box -->

<script>
        $(document).ready(function() {
            $('#ClassApplied').on('change', function() {
                var classApplied = $(this).val();
                if (classApplied) {
                    $.ajax({
                        url: '/students/' + classApplied,
                        type: 'GET',
                        dataType: 'json',
                        success: function(data) {
                            $('#StudentName').empty();
                            $('#StudentName').append('<option value="">Select Student</option>');
                            $.each(data, function(key, value) {
                                $('#StudentName').append('<option value="' + value + '">' + value + '</option>');
                            });
                        }
                    });
                } else {
                    $('#StudentName').empty();
                    $('#StudentName').append('<option value="">Select a class first</option>');
                }
            });
        });
    </script>
  </body>
</html>