<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Hello, world!</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            /* width: 200% */
        }
        .error{
            color:red;
        }
        .container {
            width: 500%;
            margin: 20px auto;
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-bottom: 10px;
            border-bottom: 1px solid #ddd;
            /* margin: 200%; */
        }
        .header h2 {
            margin: 0;
        }
        .form-section {
            display: flex;
            margin-top: 20px;
            /* margin: 200%; */
        }
        .form-section .nav {
            width: 20%;
            background-color: #2a3f54;
            color: white;
            padding: 10px;
        }
        .form-section .nav ul {
            list-style-type: none;
            padding: 0;
        }
        .form-section .nav ul li {
            padding: 10px 0;
            border-bottom: 1px solid #3c4b5a;
        }
        .form-section .nav ul li a {
            color: white;
            text-decoration: none;
        }
        .form-section .nav ul li a:hover {
            text-decoration: underline;
        }
        .form-content {
            width: 80%;
            padding: 20px;
        }
        .form-group {
            display: flex;
            margin-bottom: 15px;
        }
        .form-group label {
            width: 25%;
            padding: 10px;
            background: #f5f5f5;
            border: 1px solid #ddd;
        }
        .form-group input,
        .form-group select {
            width: 75%;
            padding: 10px;
            border: 1px solid #ddd;
            border-left: none;
        }
        .form-group input[type="radio"] {
            width: auto;
            margin-right: 10px;
        }

        .submitted_admission{
            /* border: 1px solid #dee2e6;
            padding: 10px;
            text-align: left;
            background-color: #FFC0CB;
            color: #495057; */

            box-sizing: border-box;
            margin-bottom: 30px;
            display: block;

        }
    </style>


  </head>
  <body>


  <div class="container">
        <div class="header">
            <h2>Pinegrove School, Subathu</h2>
            <div>Admin Pinegrove School</div>
        </div>
        <div class="form-section">
            <div class="nav">
                <ul>
                    <li><a href="admission_info">Admission Info</a></li>
                    <li><a href="personal_info">Personal Info</a></li>
                    <li><a href="sibling_info">Sibling Info</a></li>
                    <li><a href="address_detail">Address Detail</a></li>
                    <li><a href="parents_info">Parent/Guardian</a></li>
                    <li><a href="academic_info">Academic Info</a></li>
                    <li><a href="contact_info">Emergency Contacts</a></li>
                    <li><a href="medical_history">Medical History</a></li>
                    <li><a href="hostel_info">Hostel Info</a></li>
                    <li><a href="concession_info">Concession Info</a></li>
                    <li><a href="documents_info">Documents Upload</a></li>
                    <li><a href="transport_detail">Transport Detail</a></li>
                </ul>

            </div>

            <div class="container">
        <h2>Admission Form</h2>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
            

            <form method="POST" action="<?php echo e(route('register-user')); ?>">
    <?php echo csrf_field(); ?>
    <?php if(isset($editid)){?>  
      <input type="hidden"  name="editid" value="<?php echo e($editid->id); ?>"> 
      <?php }?>
    <div class="form-content">
                <div class="form-group">
                    <label for="admissionNo">Admission No.</label>
                    <select class="form-control" name="admission_num" id="admissionNo">
                        <option>--Select--</option>
                        <?php $__currentLoopData = $admissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($user->admissionNo); ?>"><?php echo e($user->admissionNo); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    
                    <input type="text" id="admissionNo" name="admissionNo123" <?php if(isset($editid)){?> value="<?php echo e($editid->admissionNo); ?>" <?php }?> >
                   
                </div>



                <div class="form-group">
                        <span>Hide name</span>
                        <input type="radio" class="form-control" name="toggleField" id="hideName">
                        <span>Hide Roll NO.</span>
                        <input type="radio" class="form-control" name="toggleField" id="hideRollNo">
                    </div>

                <div class="form-group">
                    <label for="admissionDate">Date of Admission</label>
                    <input type="date" id="admissionDate" name="admissionDate" value="2024-06-26">
                    <?php if($errors->has('admissionDate')): ?>
                      <div class="error" ><?php echo e($errors->first('admissionDate')); ?></div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="rollNo">B-ID/Roll No.</label>
                    <input type="text" id="rollNo" name="rollNo1" <?php if(isset($editid)){?> value="<?php echo e($editid->rollNo); ?>" <?php }?> >
                    <?php if($errors->has('rollNo')): ?>
                    <div class="error" ><?php echo e($errors->first('rollNo')); ?></div>
                    <?php endif; ?>
                </div>

               
                <div class="form-group" >
                    <label for="studentName">Student Name</label>
                    <input type="text" id="studentName" name="studentName" <?php if(isset($editid)){?> value="<?php echo e($editid->studentName); ?>" <?php }?>>
                    <?php if($errors->has('studentName')): ?>
                        <div class="error" ><?php echo e($errors->first('studentName')); ?></div>
                    <?php endif; ?>
                </div>



                <div class="row">

                    <div class="col-lg-6">
                        <label for="ClassApplied">Class</label>
                        <select class="form-control" name="class_applied" id="ClassApplied " >
                            <option>select</option>

                           <?php $__currentLoopData = $distinctclass; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarik): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tarik->classApplied); ?>"><?php echo e($tarik->classApplied); ?></option>
                          
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-lg-6">
                        <label for="StudentName">Student Name</label>
                        <select class="form-control" name="student_name" id="StudentName" >
                            <option value="<?php echo e($tarik->ClassApplied); ?>"><?php echo e($tarik->ClassApplied); ?></option>

                        </select>
                    </div>


                </div><br><br>


               
                <div class="form-group">
                    <label for="classApplied">Class Applied For</label>
                    <select id="classApplied" name="classApplied" value="<?php echo e(old('classApplied')); ?>">
                        <option>Select</option>
                        <option <?php if(isset($editid) && $editid->classApplied='first' ){ echo "selected";   }?> value="first">first</option>
                        <option  <?php if(isset($editid) && $editid->classApplied='second' ){ echo "selected";   }?> value="second">second</option>
                    </select>
                    <?php if($errors->has('classApplied')): ?>
                         <div class="error" ><?php echo e($errors->first('classApplied')); ?></div>
                     <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="section">Section</label>
                    <select class="form-control" name="section" id="section" value="<?php echo e(old('section')); ?>">
                        <option>Select</option>
                        <option <?php if(isset($editid) && $editid->section='Lotus' ){ echo "selected";   }?> value="Lotus">Lotus</option>
                        <option <?php if(isset($editid) && $editid->section='Rose' ){ echo "selected";   }?> value="Rose">Rose</option>
                        <option <?php if(isset($editid) && $editid->section='Tulip' ){ echo "selected";   }?> value="Tulip">Tulip</option>
                    </select>
                    <?php if($errors->has('section')): ?>
                    <div class="error" ><?php echo e($errors->first('section')); ?></div>
                    <?php endif; ?>
                </div>
 

                <div class="form-group">
                    <label for="gender">Gender</label>
                    <select class="form-control" name="gender" id="gender">
                        <option>Select</option>
                        <option <?php if(isset($editid) && $editid->gender='male' ){ echo "selected";   }?> value="male">male</option>
                        <option <?php if(isset($editid) && $editid->gender='female' ){ echo "selected";   }?> value="female">female</option>
                    </select>
                    <?php if($errors->has('gender')): ?>
                      <div class="error" ><?php echo e($errors->first('gender')); ?></div>
                     <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="house">House</label>
                    <select class="form-control" name="house" id="house" value="<?php echo e(old('house')); ?>">
                        <option>Select</option>
                        <option <?php if(isset($editid) && $editid->house='bunglow' ){ echo "selected";   }?> value="bunglow">bunglow</option>
                        <option <?php if(isset($editid) && $editid->house='apartment' ){ echo "selected";   }?> value="apartment">apartment</option>  
                   </select>
                    <?php if($errors->has('house')): ?>
                                            <div class="error" ><?php echo e($errors->first('house')); ?></div>
                    <?php endif; ?>
                </div>

                
                <div class="form-group">
                    <label for="studentType">Student Type</label>
                    <select class="form-control" name="studentType" id="studentType">
                    <?php if($errors->has('studentType')): ?>
                                        <div class="error" ><?php echo e($errors->first('studentType')); ?></div>
                                    <?php endif; ?>
                <option <?php if(isset($editid) && $editid->studentType='Intelligent' ){ echo "selected";   }?> value="Intelligent">Intelligent</option>
                <option <?php if(isset($editid) && $editid->studentType='Average' ){ echo "selected";   }?> value="Average">Average</option>
                    
                </select>
                </div>
                <div class="form-group">
                    <label for="nationality">Nationality</label>
                    <select class="form-control" name="nationality" id="nationality">
                    <?php if($errors->has('nationality')): ?>
                                        <div class="error" ><?php echo e($errors->first('nationality')); ?></div>
                                    <?php endif; ?>
                <option <?php if(isset($editid) && $editid->nationality='Indian' ){ echo "selected";   }?> value="Indian">Indian</option>
                <option <?php if(isset($editid) && $editid->nationality='Muslim' ){ echo "selected";   }?> value="Muslim">Muslim</option>
                    
                </select>
                </div>
                <div class="form-group">
                    <label for="stream">Stream/Wing</label>
                    <select class="form-control" name="streamWing" id="streamWing">
                    <?php if($errors->has('streamWing')): ?>
                                        <div class="error" ><?php echo e($errors->first('streamWing')); ?></div>
                                    <?php endif; ?>
                <option <?php if(isset($editid) && $editid->streamWing='first' ){ echo "selected";   }?> value="first">first</option>
                <option <?php if(isset($editid) && $editid->streamWing='second' ){ echo "selected";   }?> value="second">second</option>
                    
                </select>
                </div>
                <div class="form-group">
                    <label for="subject">Optional Subject</label>
                    <select class="form-control" name="optionalSubject" id="optionalSubject">
                    <?php if($errors->has('optionalSubject')): ?>
                                        <div class="error" ><?php echo e($errors->first('optionalSubject')); ?></div>
                                    <?php endif; ?>
                <option <?php if(isset($editid) && $editid->optionalSubject='Hindi' ){ echo "selected";   }?> value="Hindi">Hindi</option>
                <option <?php if(isset($editid) && $editid->optionalSubject='English' ){ echo "selected";   }?> value="English">English</option>
                <option <?php if(isset($editid) && $editid->optionalSubject='Chemistry' ){ echo "selected";   }?> value="Chemistry">Chemistry</option>
                <option <?php if(isset($editid) && $editid->optionalSubject='Mathematics' ){ echo "selected";   }?> value="Mathematics">Mathematics</option>
                    
                </select>
                </div>

                <div class="form-group">
                <label for="reference">Reference (if any)</label>
                <input type="text" class="form-control" name="refrence" id="reference" <?php if(isset($editid)){?> value="<?php echo e($editid->orientationDate); ?>" <?php }?>>
            </div>

                <div class="form-group">
                    <label for="orientationDate">Orientation Date</label>
                    <input type="date" id="orientationDate" name="orientationDate" <?php if(isset($editid)){?> value="<?php echo e($editid->orientationDate); ?>" <?php }?>>
                    <?php if($errors->has('orientationDate')): ?>
                       <div class="error" ><?php echo e($errors->first('orientationDate')); ?></div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="branch">Branch Preference</label>
                        <select class="form-control" name="branchPreference" id="branchPreference">
                            <option <?php if(isset($editid)){?> value="<?php echo e($editid->branchPreference); ?>" <?php }?> value="Lotus">Lotus</option>
                            <option <?php if(isset($editid)){?> value="<?php echo e($editid->branchPreference); ?>" <?php }?> value="Tulip">Tulip</option>
                            <option <?php if(isset($editid)){?> value="<?php echo e($editid->branchPreference); ?>" <?php }?> value="Rose">Rose</option>
                            <option <?php if(isset($editid)){?> value="<?php echo e($editid->branchPreference); ?>" <?php }?> value="Cherry">Cherry</option>
                        </select>
                <?php if($errors->has('branchPreference')): ?>
                    <div class="error" ><?php echo e($errors->first('branchPreference')); ?></div>
                <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="securityCase">Security Case</label>
                    <span>Yes</span><input type="radio" id="securityCaseYes" name="securityCase" value="Yes" <?php if(isset($editid) && $editid->securityCase='Yes' ){ echo "checked";   }?> checked>
                    <span>No</span> <input type="radio" id="securityCaseNo" name="securityCase" value="No" <?php if(isset($editid) && $editid->securityCase='No' ){ echo "checked";   }?>> 
                    <?php if($errors->has('securityCase')): ?>
                         <div class="error"  ><?php echo e($errors->first('securityCase')); ?></div>
                     <?php endif; ?>
                </div>
            </div>

            <button type="submit" class="btn btn-primary">Submit</button>

            <div class="submitted_admission">
<h2>Submitted Admissions</h2>
        <table class="table table-striped" border='1'>
            <thead>
                <tr>
                    <th>Admission No</th>
                    <th>Roll No</th>
                    <th>Class Applied</th>
                    <th>Admission Date</th>
                    <th>Orientation Date</th>
                    <th>Student Name</th>
                    <th>Section</th>
                    <th>Gender</th>
                    <th>House</th>
                    <th>Student Type</th>
                    <th>Nationality</th>
                    <th>Stream Wing</th>
                    <th>Optional Subject</th>
                    <th>Reference</th>
                    <th>Branch Preference</th>
                    <th>Security Case</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $admissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($admission->admissionNo); ?></td>
                        <td><?php echo e($admission->rollNo); ?></td>
                        <td><?php echo e($admission->classApplied); ?></td>
                        <td><?php echo e($admission->admissionDate); ?></td>
                        <td><?php echo e($admission->orientationDate); ?></td>
                        <td><?php echo e($admission->studentName); ?></td>
                        <td><?php echo e($admission->section); ?></td>
                        <td><?php echo e($admission->gender); ?></td>
                        <td><?php echo e($admission->house); ?></td>
                        <td><?php echo e($admission->studentType); ?></td>
                        <td><?php echo e($admission->nationality); ?></td>
                        <td><?php echo e($admission->streamWing); ?></td>
                        <td><?php echo e($admission->optionalSubject); ?></td>
                        <td><?php echo e($admission->reference); ?></td>
                        <td><?php echo e($admission->branchPreference); ?></td>
                        <td><?php echo e($admission->securityCase); ?></td>
                        <td>
                        <!-- <button class="btn btn-warning" onclick="editAdmission(<?php echo e($admission->id); ?>)">Edit</button> -->
                         <a href="<?php echo e(route('update',$admission->id)); ?>"><button type="button" class="btn-success">Edit</button></a>
                         <a href="<?php echo e(route('destroy',$admission->id)); ?>"><button type="button" class="btn btn-danger">Delete</button></a>
                         </td>


                    </tr>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
</div>


<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form id="editForm" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Edit Admission</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                
            </form>
        </div>
    </div>
</div>


    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>



    <script>
        $(document).ready(function() {
            $('input[type=radio][name=toggleField]').change(function() {
                if (this.id == 'hideName') {
                    $('#studentName').hide();
                } else if (this.id == 'hideRollNo') {
                    $('#rollNo').hide();
                }
            });
        });
    </script>


 <script>
$(document).ready(function() {
    $(document).on('change', '#admissionNo', function () {
        var admissionNo = $('#admissionNo').val();
        
        console.log("admission number id is " + admissionNo)

        $.ajax({
            url: '<?php echo e(route('get_admission_data')); ?>',
            method: 'GET',
            data: {'admissionNo': admissionNo},
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            },
            success: function (response) {
                console.log("Success:", response);

                $('#studentName').val(response.studentName);
                $('#dateOfAdmission').val(response.admissionDate);
                $('#classAppliedFor').val(response.classApplied);
                $('#section').val(response.section);
                $('#gender').val(response.gender);
                $('#house').val(response.house);
                $('#studentType').val(response.studentType);
                $('#nationality').val(response.nationality);
                $('#streamWing').val(response.streamWing);
                $('#optionalSubject').val(response.optionalSubject);
                $('#orientationDate').val(response.orientationDate);
                $('#branchPreference').val(response.branchPreference);
            },
            error: function (xhr, status, error) {
                console.error("AJAX Error:", error);
            }
        });
    });
});


</script>
 <!-- fetch data in options box coreespondint to another box -->

<script>
        $(document).ready(function() {
            $('#ClassApplied').on('change', function() {
                var classApplied = $(this).val();
                if (classApplied) {
                    $.ajax({
                        url: '/students/' + classApplied,
                        type: 'GET',
                        dataType: 'json',
                        success: function(data) {
                            $('#StudentName').empty();
                            $('#StudentName').append('<option value="">Select Student</option>');
                            $.each(data, function(key, value) {
                                $('#StudentName').append('<option value="' + value + '">' + value + '</option>');
                            });
                        }
                    });
                } else {
                    $('#StudentName').empty();
                    $('#StudentName').append('<option value="">Select a class first</option>');
                }
            });
        });
    </script>
  </body>
</html><?php /**PATH C:\xampp\htdocs\di_project_form_submission\resources\views/index.blade.php ENDPATH**/ ?>