<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
             Schema::create('admissions', function (Blueprint $table) {
            $table->id();
            $table->string('admissionNo');
            $table->date('admissionDate');
            $table->string('rollNo')->nullable();
            $table->string('studentName');
            $table->string('classApplied');
            $table->string('section');
            $table->string('gender');
            $table->string('house');
            $table->string('studentType');
            $table->string('nationality');
            $table->string('streamWing');
            $table->string('optionalSubject');
            $table->date('orientationDate')->nullable();
            $table->string('branchPreference');
            $table->string('securityCase');
            $table->timestamps();
        });
    }

  


    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('admissions');
    }
};
